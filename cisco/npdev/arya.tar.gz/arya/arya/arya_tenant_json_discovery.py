#!/usr/bin/env python

# list of packages that should be imported for this code to work
import cobra.mit.access
import cobra.mit.request
import cobra.mit.session
import cobra.model.fv
import cobra.model.pol
import cobra.model.vz
from cobra.internal.codec.xmlcodec import toXMLStr

# log into an APIC and create a directory object
ls = cobra.mit.session.LoginSession('https://apic', 'admin', 'cisco123')
md = cobra.mit.access.MoDirectory(ls)
md.login()

# the top level object on which operations will be made
polUni = cobra.model.pol.Uni('')

# build the request using cobra syntax
fvTenant = cobra.model.fv.Tenant(polUni, ownerKey=u'', name=u'Cobra_Tenant_1', descr=u'', ownerTag=u'')
fvCtx = cobra.model.fv.Ctx(fvTenant, seg=u'2326528', ownerKey=u'', name=u'pvn1', descr=u'', knwMcastAct=u'permit', pcEnfDir=u'ingress', pcTag=u'16386', pcEnfDirUpdated=u'yes', ownerTag=u'', pcEnfPref=u'enforced')
fvRsCtxToExtRouteTagPol = cobra.model.fv.RsCtxToExtRouteTagPol(fvCtx, tRn=u'rttag-default', tDn=u'uni/tn-common/rttag-default', rType=u'mo', tCl=u'l3extRouteTagPol', tContextDn=u'', forceResolve=u'yes', tnL3extRouteTagPolName=u'', tType=u'name')
fvRsBgpCtxPol = cobra.model.fv.RsBgpCtxPol(fvCtx, tRn=u'bgpCtxP-default', tDn=u'uni/tn-common/bgpCtxP-default', rType=u'mo', tnBgpCtxPolName=u'', tCl=u'bgpCtxPol', tContextDn=u'', forceResolve=u'yes', tType=u'name')
vzAny = cobra.model.vz.Any(fvCtx, matchT=u'AtleastOne', name=u'', descr=u'', pcTag=u'any', useAnyDef=u'yes')
fvRsOspfCtxPol = cobra.model.fv.RsOspfCtxPol(fvCtx, tRn=u'ospfCtxP-default', tDn=u'uni/tn-common/ospfCtxP-default', rType=u'mo', tCl=u'ospfCtxPol', tnOspfCtxPolName=u'', tContextDn=u'', forceResolve=u'yes', tType=u'name')
fvRsCtxToEpRet = cobra.model.fv.RsCtxToEpRet(fvCtx, tRn=u'epRPol-default', tDn=u'uni/tn-common/epRPol-default', rType=u'mo', tCl=u'fvEpRetPol', tContextDn=u'', forceResolve=u'yes', tType=u'name', tnFvEpRetPolName=u'')
fvBD = cobra.model.fv.BD(fvTenant, multiDstPktAct=u'bd-flood', seg=u'16089026', unicastRoute=u'yes', unkMcastAct=u'flood', descr=u'', llAddr=u'::', vmac=u'not-applicable', bcastP=u'225.1.84.192', mac=u'00:22:BD:F8:19:FF', epMoveDetectMode=u'', ownerTag=u'', ownerKey=u'', name=u'bd1', unkMacUcastAct=u'proxy', arpFlood=u'no', limitIpLearnToSubnets=u'no', mtu=u'inherit', pcTag=u'49153')
fvRsBDToNdP = cobra.model.fv.RsBDToNdP(fvBD, tRn=u'ndifpol-default', tDn=u'uni/tn-common/ndifpol-default', rType=u'mo', tCl=u'ndIfPol', tContextDn=u'', forceResolve=u'yes', tType=u'name', tnNdIfPolName=u'')
fvRsCtx = cobra.model.fv.RsCtx(fvBD, tRn=u'ctx-pvn1', tDn=u'uni/tn-Cobra_Tenant_1/ctx-pvn1', rType=u'mo', tCl=u'fvCtx', tContextDn=u'', forceResolve=u'yes', tType=u'name', tnFvCtxName=u'pvn1')
fvRsIgmpsn = cobra.model.fv.RsIgmpsn(fvBD, tRn=u'snPol-default', tDn=u'uni/tn-common/snPol-default', rType=u'mo', tnIgmpSnoopPolName=u'', tCl=u'igmpSnoopPol', tContextDn=u'', forceResolve=u'yes', tType=u'name')
fvRsBdToEpRet = cobra.model.fv.RsBdToEpRet(fvBD, tRn=u'epRPol-default', tDn=u'uni/tn-common/epRPol-default', rType=u'mo', tContextDn=u'', resolveAct=u'resolve', forceResolve=u'yes', tCl=u'fvEpRetPol', tType=u'name', tnFvEpRetPolName=u'')
fvRsTenantMonPol = cobra.model.fv.RsTenantMonPol(fvTenant, tRn=u'monepg-default', tDn=u'uni/tn-common/monepg-default', rType=u'mo', tCl=u'monEPGPol', tContextDn=u'', forceResolve=u'yes', tType=u'name', tnMonEPGPolName=u'')
fvAp = cobra.model.fv.Ap(fvTenant, ownerKey=u'', name=u'OnlineStore1', descr=u'', ownerTag=u'', prio=u'unspecified')
fvAEPg = cobra.model.fv.AEPg(fvAp, isAttrBasedEPg=u'no', matchT=u'AtleastOne', name=u'app1', descr=u'', txId=u'17870283321406128784', pcTag=u'32770', prio=u'unspecified', pcEnfPref=u'unenforced')
fvRsCustQosPol = cobra.model.fv.RsCustQosPol(fvAEPg, tRn=u'qoscustom-default', tDn=u'uni/tn-common/qoscustom-default', tnQosCustomPolName=u'', rType=u'mo', tCl=u'qosCustomPol', tContextDn=u'', forceResolve=u'yes', tType=u'name')
fvRsBd = cobra.model.fv.RsBd(fvAEPg, tRn=u'BD-bd1', tDn=u'uni/tn-Cobra_Tenant_1/BD-bd1', rType=u'mo', tCl=u'fvBD', tContextDn=u'', forceResolve=u'yes', tnFvBDName=u'bd1', tType=u'name')
fvSubnetBDDefCont = cobra.model.fv.SubnetBDDefCont(fvRsBd, name=u'', bddefDn=u'uni/bd-[uni/tn-Cobra_Tenant_1/BD-bd1]-isSvc-no')
fvAEPg2 = cobra.model.fv.AEPg(fvAp, isAttrBasedEPg=u'no', matchT=u'AtleastOne', name=u'web1', descr=u'', txId=u'17870283321406128784', pcTag=u'16388', prio=u'unspecified', pcEnfPref=u'unenforced')
fvRsCustQosPol2 = cobra.model.fv.RsCustQosPol(fvAEPg2, tRn=u'qoscustom-default', tDn=u'uni/tn-common/qoscustom-default', tnQosCustomPolName=u'', rType=u'mo', tCl=u'qosCustomPol', tContextDn=u'', forceResolve=u'yes', tType=u'name')
fvRsBd2 = cobra.model.fv.RsBd(fvAEPg2, tRn=u'BD-bd1', tDn=u'uni/tn-Cobra_Tenant_1/BD-bd1', rType=u'mo', tCl=u'fvBD', tContextDn=u'', forceResolve=u'yes', tnFvBDName=u'bd1', tType=u'name')
fvSubnetBDDefCont2 = cobra.model.fv.SubnetBDDefCont(fvRsBd2, name=u'', bddefDn=u'uni/bd-[uni/tn-Cobra_Tenant_1/BD-bd1]-isSvc-no')
fvAEPg3 = cobra.model.fv.AEPg(fvAp, isAttrBasedEPg=u'no', matchT=u'AtleastOne', name=u'db1', descr=u'', txId=u'17870283321406128784', pcTag=u'16387', prio=u'unspecified', pcEnfPref=u'unenforced')
fvRsCustQosPol3 = cobra.model.fv.RsCustQosPol(fvAEPg3, tRn=u'qoscustom-default', tDn=u'uni/tn-common/qoscustom-default', tnQosCustomPolName=u'', rType=u'mo', tCl=u'qosCustomPol', tContextDn=u'', forceResolve=u'yes', tType=u'name')
fvRsBd3 = cobra.model.fv.RsBd(fvAEPg3, tRn=u'BD-bd1', tDn=u'uni/tn-Cobra_Tenant_1/BD-bd1', rType=u'mo', tCl=u'fvBD', tContextDn=u'', forceResolve=u'yes', tnFvBDName=u'bd1', tType=u'name')
fvSubnetBDDefCont3 = cobra.model.fv.SubnetBDDefCont(fvRsBd3, name=u'', bddefDn=u'uni/bd-[uni/tn-Cobra_Tenant_1/BD-bd1]-isSvc-no')


# commit the generated code to APIC
print toXMLStr(polUni)
c = cobra.mit.request.ConfigRequest()
c.addMo(fvTenant)
md.commit(c)

