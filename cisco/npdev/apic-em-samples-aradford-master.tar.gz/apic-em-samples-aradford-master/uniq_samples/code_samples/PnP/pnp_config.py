CONFIGS_DIR= "work_files/configs/"
DEVICES="work_files/inventory.csv"
TEMPLATE="work_files/templates/config_template.jnj"


# name wrap function is used to create unique filenames, project_names, and serial numbers
# used for shared labs
USE_NAME_WRAP=True
#USE_NAME_WRAP=False