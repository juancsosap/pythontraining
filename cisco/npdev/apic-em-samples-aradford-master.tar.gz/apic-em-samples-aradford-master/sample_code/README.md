APIC-EM Sample Scripts
======================

This directory contains some sample python scripts for APIC-EM.  

These examples are python2.

May need to change user/password in ```apic_config.py```.  You can also change controllers here too and point to your own controller.

The directory PnP contains some examples specifically for Network Plug and Play (PnP)
